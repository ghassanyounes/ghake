var files_dup =
[
    [ "compile.cpp", "compile_8cpp.html", "compile_8cpp" ],
    [ "doxy.cpp", "doxy_8cpp.html", "doxy_8cpp" ],
    [ "functions.h", "functions_8h.html", "functions_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "makers.cpp", "makers_8cpp.html", "makers_8cpp" ],
    [ "memchk.cpp", "memchk_8cpp.html", "memchk_8cpp" ]
];