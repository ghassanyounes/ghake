var namespaces_dup =
[
    [ "basemake", "namespacebasemake.html", null ],
    [ "doxygen", "namespacedoxygen.html", null ],
    [ "memorydebug", "namespacememorydebug.html", null ]
];