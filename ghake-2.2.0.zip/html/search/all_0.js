var searchData=
[
  ['basemake',['basemake',['../namespacebasemake.html',1,'']]],
  ['baserules',['baserules',['../namespacebasemake.html#aba29fb226ec50e939d89f85346f2bc55',1,'basemake']]]
];
