var searchData=
[
  ['failed',['FAILED',['../functions_8h.html#a32c27cc471df37f4fc818d65de0a56c4aecedb56d1405a60c6069f4a0139bdec5',1,'functions.h']]],
  ['file_5ferr',['FILE_ERR',['../functions_8h.html#a32c27cc471df37f4fc818d65de0a56c4ace97aa1ba9b4a75ee1dae036e815e15e',1,'functions.h']]]
];
