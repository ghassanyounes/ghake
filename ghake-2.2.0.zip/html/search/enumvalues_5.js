var searchData=
[
  ['microsoft',['MICROSOFT',['../namespacecompilation.html#ab8b552e73f4f5a4912982468f052f089ae1c2380a9921008e2f3adc077e1f9db1',1,'compilation']]]
];
