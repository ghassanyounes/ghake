var searchData=
[
  ['ok',['OK',['../functions_8h.html#a32c27cc471df37f4fc818d65de0a56c4a2bc49ec37d6a5715dd23e85f1ff5bb59',1,'functions.h']]]
];
