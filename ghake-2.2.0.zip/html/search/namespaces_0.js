var searchData=
[
  ['basemake',['basemake',['../namespacebasemake.html',1,'']]]
];
