var searchData=
[
  ['project_5fname',['project_name',['../structinfo.html#a6c3220ad8461c17ddf7aa0e1eeccc609',1,'info']]]
];
