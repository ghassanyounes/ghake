var structcompilation_1_1compinfo =
[
    [ "compilargs", "structcompilation_1_1compinfo.html#ad9cefd1d374086e188938894670e9080", null ],
    [ "compilername", "structcompilation_1_1compinfo.html#a3a2cfa30a4f643b51b69e850daad2a0f", null ],
    [ "comptype", "structcompilation_1_1compinfo.html#aa18069ec11f1df8741bc8d4c814de893", null ]
];