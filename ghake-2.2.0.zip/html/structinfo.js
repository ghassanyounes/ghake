var structinfo =
[
    [ "compinfo", "structinfo.html#a32634b4fda7eaf66c4678004f0fb3e06", null ],
    [ "diff_file", "structinfo.html#a02ab1e784aaa44a78d7a8956c56acaa5", null ],
    [ "filex", "structinfo.html#af19214faa8cce0591e0fa20277a8093f", null ],
    [ "makefile", "structinfo.html#ab769fb22f9c7889b7dcf3521feb681e6", null ],
    [ "mdinfo", "structinfo.html#a069a3d90d3cd5e2a85ebe50badcf6329", null ],
    [ "project_name", "structinfo.html#a6c3220ad8461c17ddf7aa0e1eeccc609", null ]
];