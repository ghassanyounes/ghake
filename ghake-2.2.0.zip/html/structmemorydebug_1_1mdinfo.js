var structmemorydebug_1_1mdinfo =
[
    [ "debugargs", "structmemorydebug_1_1mdinfo.html#a5ecc30840a8eff62b47f3844d6ac914a", null ],
    [ "debugname", "structmemorydebug_1_1mdinfo.html#a5257a91acea04df5a46eb52a2145689e", null ],
    [ "debugtype", "structmemorydebug_1_1mdinfo.html#a3cf207fafb9af734c16517ce2f31f25c", null ]
];